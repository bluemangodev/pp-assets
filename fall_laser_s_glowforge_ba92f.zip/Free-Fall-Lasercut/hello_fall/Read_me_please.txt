Black line - cut line
Blue line - score

The files are designed for a 3mm thick material, if you use a different thickness material, you can edit the file yourself, if you don't know how to do it - write to me on DB and I edit the file for you for free. If you have questions - write to me, I am always happy to help!:)